public class QuickSort {
    // ==========================================
    // 4. Quick Sort
    // Complexidade: O(n log n) médio - Muito rápido na prática, também adaptável para paralelismo.
    // ==========================================
    public static void quickSort(int[] arr, int inicio, int fim) {
        if (inicio < fim) {
            int indiceParticao = particiona(arr, inicio, fim);

            quickSort(arr, inicio, indiceParticao - 1);
            quickSort(arr, indiceParticao + 1, fim);
        }
    }

    private static int particiona(int[] arr, int inicio, int fim) {
        int pivo = arr[fim];
        int i = (inicio - 1); // Índice do menor elemento

        for (int j = inicio; j < fim; j++) {
            if (arr[j] <= pivo) {
                i++;
                // Troca arr[i] e arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // Troca arr[i+1] e arr[fim] (ou o pivô)
        int temp = arr[i + 1];
        arr[i + 1] = arr[fim];
        arr[fim] = temp;

        return i + 1;
    }

}