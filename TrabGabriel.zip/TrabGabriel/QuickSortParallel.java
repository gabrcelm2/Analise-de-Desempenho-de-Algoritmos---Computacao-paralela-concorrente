import java.util.concurrent.RecursiveAction;

public class QuickSortParallel extends RecursiveAction {
    private int[] arr;
    private int inicio;
    private int fim;
    private static final int THRESHOLD = 10000;

    public QuickSortParallel(int[] arr, int inicio, int fim) {
        this.arr = arr;
        this.inicio = inicio;
        this.fim = fim;
    }

    @Override
    protected void compute() {
        if (inicio < fim) {
            // Se o pedaço for pequeno, resolvemos com a sua classe Serial
            if (fim - inicio < THRESHOLD) {
                QuickSort.quickSort(arr, inicio, fim);
            } else {
                // Caso contrário, dividimos (particionamos) o array
                int indiceParticao = particiona(arr, inicio, fim);

                // Criamos as tarefas paralelas para ordenar os dois lados do pivô
                QuickSortParallel tarefaEsquerda = new QuickSortParallel(arr, inicio, indiceParticao - 1);
                QuickSortParallel tarefaDireita = new QuickSortParallel(arr, indiceParticao + 1, fim);

                invokeAll(tarefaEsquerda, tarefaDireita);
            }
        }
    }

    // A lógica de particionamento (Lomuto) é idêntica à sua classe serial
    private int particiona(int[] arr, int inicio, int fim) {
        int pivo = arr[fim];
        int i = (inicio - 1);

        for (int j = inicio; j < fim; j++) {
            if (arr[j] <= pivo) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[fim];
        arr[fim] = temp;

        return i + 1;
    }
}