import pandas as pd
import plotly.express as px

# 1. Carregar os dados gerados pelo seu programa Java
df = pd.read_csv('resultados_completos.csv')

# 2. Calcular o tempo médio das amostras
df_mean = df.groupby(['Algoritmo', 'Natureza', 'Tamanho', 'Threads'])['Tempo_ms'].mean().reset_index()

# 3. Filtrar os dados:
# Pegamos 'Aleatorio' e forçamos 'Threads == 1'. 
# Isso é crucial porque Bubble e Insertion só rodam com 1 Thread, então a comparação precisa ser justa (Serial vs Serial).
df_comparacao = df_mean[(df_mean['Natureza'] == 'Aleatorio') & (df_mean['Threads'] == 1)]

# 4. Criar o Gráfico Dinâmico de Comparação Geral
fig3 = px.line(df_comparacao, 
               x='Tamanho', 
               y='Tempo_ms', 
               color='Algoritmo', 
               markers=True,
               title='Comparação de Tempo - Execução Serial',
               labels={'Tamanho': 'Tamanho do Array', 'Tempo_ms': 'Tempo Médio (ms)', 'Algoritmo': 'Algoritmo'},
               log_y=True) # <-- A MÁGICA AQUI: log_y=True transforma o eixo Y em escala logarítmica!

# Configurações para forçar o eixo X a mostrar apenas os tamanhos que você testou (10k e 50k)
fig3.update_layout(xaxis=dict(tickvals=[10000, 50000]))

# 5. Exibir e Salvar
fig3.show()
fig3.write_html("grafico_comparacao_todos_algoritmos.html")
print("Gráfico de Comparação Geral salvo como 'grafico_comparacao_todos_algoritmos.html'!")