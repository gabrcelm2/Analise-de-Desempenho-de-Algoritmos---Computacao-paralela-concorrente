
public class BubbleSort {   // ==========================================
    // 1. Bubble Sort
    // Complexidade: O(n^2) - Ideal para fins didáticos e arrays quase ordenados.
    // ==========================================
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean trocou;
        for (int i = 0; i < n - 1; i++) {
            trocou = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // Troca os elementos
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    trocou = true;
                }
            }
            // Se nenhuma troca foi feita na passagem interna, o array já está ordenado
            if (!trocou) break;
        }
    }
}