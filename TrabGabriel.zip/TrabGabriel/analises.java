import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.Locale;

public class analises {

    public static void main(String[] args) {
        int[] tamanhos = {10000, 50000, 100000, 500000};
        int[] threads = {1, 2, 4, 8}; // 1 = Serial
        int amostras = 5;
        String[] naturezas = {"Aleatorio", "Ordenado", "Inverso"};
        String[] algoritmos = {"MergeSort", "QuickSort", "BubbleSort", "InsertionSort"};

        System.out.println("Iniciando Benchmark Completo... Isso pode demorar!");

        try (FileWriter csvWriter = new FileWriter("resultados_completos.csv")) {
            csvWriter.append("Algoritmo,Natureza,Tamanho,Threads,Amostra,Tempo_ms\n");

            for (int tamanho : tamanhos) {
                int[] arrayAleatorio = gerarArrayAleatorio(tamanho);
                int[] arrayOrdenado = arrayAleatorio.clone();
                Arrays.sort(arrayOrdenado);
                int[] arrayInverso = inverterArray(arrayOrdenado);

                for (String natureza : naturezas) {
                    int[] baseArray;
                    if (natureza.equals("Aleatorio")) baseArray = arrayAleatorio;
                    else if (natureza.equals("Ordenado")) baseArray = arrayOrdenado;
                    else baseArray = arrayInverso;

                    for (String algoritmo : algoritmos) {
                        
                        // Bubble e Insertion só rodam com 1 Thread (Serial)
                        // E vamos pular eles para o tamanho 500.000 para seu PC não travar por horas
                        if ((algoritmo.equals("BubbleSort") || algoritmo.equals("InsertionSort"))) {
                            if (tamanho > 100000) continue; // Pula tamanhos gigantes para O(n^2)
                            
                            executarEGravar(csvWriter, algoritmo, natureza, tamanho, 1, amostras, baseArray);
                        } 
                        else {
                            // Merge e Quick rodam com todas as variações de threads
                            for (int t : threads) {
                                executarEGravar(csvWriter, algoritmo, natureza, tamanho, t, amostras, baseArray);
                            }
                        }
                    }
                }
                System.out.println("Concluído benchmark para tamanho: " + tamanho);
            }
            System.out.println("Benchmark finalizado! Arquivo 'resultados_completos.csv' gerado com sucesso.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void executarEGravar(FileWriter csvWriter, String algoritmo, String natureza, int tamanho, int t, int amostras, int[] baseArray) throws IOException {
        for (int a = 1; a <= amostras; a++) {
            int[] copia = baseArray.clone();
            long inicio = System.nanoTime();

            if (algoritmo.equals("BubbleSort")) {
                BubbleSort.bubbleSort(copia);
            } else if (algoritmo.equals("InsertionSort")) {
                InsertionSort.insertionSort(copia);
            } else if (algoritmo.equals("MergeSort")) {
                if (t == 1) MergeSort.mergeSort(copia, 0, copia.length - 1);
                else {
                    ForkJoinPool pool = new ForkJoinPool(t);
                    pool.invoke(new MergeSortParallel(copia, 0, copia.length - 1));
                    pool.shutdown();
                }
            } else if (algoritmo.equals("QuickSort")) {
                if (t == 1) QuickSort.quickSort(copia, 0, copia.length - 1);
                else {
                    ForkJoinPool pool = new ForkJoinPool(t);
                    pool.invoke(new QuickSortParallel(copia, 0, copia.length - 1));
                    pool.shutdown();
                }
            }

            long fim = System.nanoTime();
            double tempoMs = (fim - inicio) / 1_000_000.0;
            csvWriter.append(String.format(Locale.US, "%s,%s,%d,%d,%d,%.4f\n", algoritmo, natureza, tamanho, t, a, tempoMs));
        }
    }

    private static int[] gerarArrayAleatorio(int tamanho) {
        Random rand = new Random();
        int[] arr = new int[tamanho];
        for (int i = 0; i < tamanho; i++) arr[i] = rand.nextInt(1000000);
        return arr;
    }

    private static int[] inverterArray(int[] arr) {
        int[] inverso = new int[arr.length];
        for (int i = 0; i < arr.length; i++) inverso[i] = arr[arr.length - 1 - i];
        return inverso;
    }
}