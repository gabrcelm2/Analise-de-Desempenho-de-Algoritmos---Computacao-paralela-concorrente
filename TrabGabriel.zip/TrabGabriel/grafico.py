import pandas as pd
import plotly.express as px

df = pd.read_csv('resultados_completos.csv')
df_mean = df.groupby(['Algoritmo', 'Natureza', 'Tamanho', 'Threads'])['Tempo_ms'].mean().reset_index()

df_paralelo = df_mean[(df_mean['Tamanho'] == 50000) & 
                      (df_mean['Natureza'] == 'Aleatorio') & 
                      (df_mean['Algoritmo'].isin(['MergeSort', 'QuickSort']))]

# 3. Criar o Gráfico Dinâmico Comparativo
fig_threads = px.line(df_paralelo, 
               x='Threads', 
               y='Tempo_ms', 
               color='Algoritmo', # Uma linha para o Merge, outra para o Quick!
               markers=True,
               title='Análise de Paralelismo: Merge Sort vs Quick Sort',
               labels={'Threads': 'Número de Núcleos (Threads)', 'Tempo_ms': 'Tempo Médio (ms)', 'Algoritmo': 'Algoritmo'})

# Forçar o eixo X a mostrar exatamente as threads que você usou
fig_threads.update_layout(xaxis=dict(tickvals=[1, 2, 4, 8]))

# 4. Exibir e Salvar
fig_threads.show()
fig_threads.write_html("grafico_threads_merge_vs_quick.html")
print("Gráfico completo de paralelismo gerado!")