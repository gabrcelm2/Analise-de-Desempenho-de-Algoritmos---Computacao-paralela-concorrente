import java.util.concurrent.RecursiveAction;

public class MergeSortParallel extends RecursiveAction {

    private int[] arr;
    private int esquerda;
    private int direita;
    // Limiar: se o pedaço do array for menor que 10.000, usamos o serial para evitar overhead de threads
    private static final int THRESHOLD = 10000; 

    public MergeSortParallel(int[] arr, int esquerda, int direita) {
        this.arr = arr;
        this.esquerda = esquerda;
        this.direita = direita;
    }

    @Override
    protected void compute() {
        if (esquerda < direita) {
            // Se o tamanho do array for pequeno, resolvemos com a sua classe Serial
            if (direita - esquerda < THRESHOLD) {
                MergeSort.mergeSort(arr, esquerda, direita);
            } else {
                // Caso contrário, dividimos e criamos duas novas tarefas paralelas
                int meio = esquerda + (direita - esquerda) / 2;

                MergeSortParallel tarefaEsquerda = new MergeSortParallel(arr, esquerda, meio);
                MergeSortParallel tarefaDireita = new MergeSortParallel(arr, meio + 1, direita);

                // O invokeAll roda as duas tarefas em paralelo e espera ambas terminarem
                invokeAll(tarefaEsquerda, tarefaDireita);

                // Por fim, fazemos o merge (mesclagem) das partes que foram ordenadas em paralelo
                merge(arr, esquerda, meio, direita);
            }
        }
    }

    // A lógica de Merge é idêntica à sua classe serial
    private void merge(int[] arr, int esquerda, int meio, int direita) {
        int n1 = meio - esquerda + 1;
        int n2 = direita - meio;
        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; ++i) L[i] = arr[esquerda + i];
        for (int j = 0; j < n2; ++j) R[j] = arr[meio + 1 + j];

        int i = 0, j = 0, k = esquerda;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i]; i++;
            } else {
                arr[k] = R[j]; j++;
            }
            k++;
        }
        while (i < n1) { arr[k] = L[i]; i++; k++; }
        while (j < n2) { arr[k] = R[j]; j++; k++; }
    }
}
    