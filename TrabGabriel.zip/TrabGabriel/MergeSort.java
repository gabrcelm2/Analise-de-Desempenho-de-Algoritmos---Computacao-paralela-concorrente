public class MergeSort {

        // ==========================================
    // 3. Merge Sort
    // Complexidade: O(n log n) - Estável, excelente para paralelização (Divide and Conquer).
    // ==========================================
    public static void mergeSort(int[] arr, int esquerda, int direita) {
        if (esquerda < direita) {
            int meio = esquerda + (direita - esquerda) / 2;

            // Ordena a primeira e a segunda metade
            mergeSort(arr, esquerda, meio);
            mergeSort(arr, meio + 1, direita);

            // Mescla as metades ordenadas
            merge(arr, esquerda, meio, direita);
        }
    }

    private static void merge(int[] arr, int esquerda, int meio, int direita) {
        int n1 = meio - esquerda + 1;
        int n2 = direita - meio;

        int[] L = new int[n1];
        int[] R = new int[n2];

        for (int i = 0; i < n1; ++i)
            L[i] = arr[esquerda + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[meio + 1 + j];

        int i = 0, j = 0;
        int k = esquerda;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
}